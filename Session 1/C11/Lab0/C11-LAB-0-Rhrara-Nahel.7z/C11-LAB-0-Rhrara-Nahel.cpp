#include <iostream>
#include <conio.h>

using namespace::std;

int main()
{
	cout << "Bonjour, je m'appelle Nahel." << endl << endl;
	cout << "j'ai 20 ans.";
	cout << "Mon dernier displome est un BAC STi2D (diplome francais)" << endl << endl;
	cout << "L'hiver passe je travaillais dans un magasin pour preaprer mon arriver ici." << endl << endl;
	cout << "Je ne pratique pas de sport, bien que j'en ai fais plusieur lorsque j'etais plus jeune, equitation, taekwondo, natation, soccer" << endl << endl;
	cout << "Je passe la majeur parti de mon temps libre sur divers jeux video ou a regarder des video de vulgarisation sur youtube." << endl << endl;

	_getch();
}